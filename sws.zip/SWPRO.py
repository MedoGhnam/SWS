﻿import threading
import random
import string
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time
import os
import pytesseract
import cv2
import re
from datetime import datetime
import tkinter as tk
from tkinter import messagebox
from queue import Queue
import queue  # Added for queue.Empty

# Setup Tesseract
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

log_file = "registered_accounts_auto_3000.txt"
error_log_file = "errors_log.txt"
config_file = "config.txt"
screenshot_folder = "screenshots"
icon_folder = "Capatcha Icon"
os.makedirs(screenshot_folder, exist_ok=True)

def load_used_emails():
    used_emails = set()
    if os.path.exists(log_file):
        with open(log_file, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    email = line.strip().split(",", 1)[0]
                    used_emails.add(email.strip())
                except:
                    continue
    return used_emails

def generate_unique_email(used_emails):
    while True:
        username = ''.join(random.choices(string.ascii_lowercase + string.digits, k=10))
        email = f"{username}@medomail.com"
        if email not in used_emails:
            used_emails.add(email)
            return email

def log_error(index, message):
    try:
        with open(error_log_file, "a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] [ERROR] [{index}] {message}\n")
    except Exception as e:
        print(f"[ERROR] Error writing to error log: {e}")

def wait_for_page_load(driver, timeout=10):
    try:
        WebDriverWait(driver, timeout).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
        print(f"[PAGE] [{driver}] Page loaded successfully")
        return True
    except Exception as e:
        print(f"[ERROR] [{driver}] Error waiting for page load: {e}")
        log_error(str(driver), f"Page load timeout after {timeout} seconds: {e}")
        return False

def solve_captcha(index, driver, max_attempts=3):
    for attempt in range(1, max_attempts + 1):
        try:
            question_text = driver.find_element(By.CSS_SELECTOR, "#sample-captcha .visualCaptcha-explanation").text.strip()
            print(f"[CAPTCHA] [{index}] OCR Captcha Question (Attempt {attempt}): {question_text}")

            match = re.search(r"Click or touch the (.+)", question_text)
            if not match:
                print(f"[ERROR] [{index}] Captcha keyword not extracted from text (Attempt {attempt})")
                log_error(index, f"Captcha keyword not extracted from text (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return False

            keyword = match.group(1).strip()
            icon_path = os.path.join(icon_folder, f"{keyword}.png")

            if not os.path.exists(icon_path):
                print(f"[ERROR] [{index}] Icon {keyword} not found (Attempt {attempt})")
                log_error(index, f"Icon image for '{keyword}' not found (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return False

            driver.execute_script("window.scrollBy(0, 300)")
            time.sleep(2)

            screenshot_path = os.path.join(screenshot_folder, f"{index}_full_attempt_{attempt}.png")
            driver.save_screenshot(screenshot_path)

            screen_raw = cv2.imread(screenshot_path)
            icon_raw = cv2.imread(icon_path)

            screen_gray = cv2.cvtColor(screen_raw, cv2.COLOR_BGR2GRAY)
            icon_gray = cv2.cvtColor(icon_raw, cv2.COLOR_BGR2GRAY)

            screen_blur = cv2.GaussianBlur(screen_gray, (5, 5), 0)
            icon_blur = cv2.GaussianBlur(icon_gray, (5, 5), 0)

            result = cv2.matchTemplate(screen_blur, icon_blur, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)

            if max_val >= 0.6:
                x, y = max_loc
                click_x = x + 15
                click_y = y + 15
                driver.execute_script("""
                    var element = document.elementFromPoint(arguments[0], arguments[1]);
                    if (element) {
                        element.click();
                    }
                """, click_x, click_y)
                print(f"[CLICK] [{index}] Clicked on: {keyword} at ({click_x},{click_y}) (Attempt {attempt})")
                return True
            else:
                print(f"[ERROR] [{index}] Icon not located with confidence (Attempt {attempt})")
                log_error(index, f"Icon not located with confidence (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return False
        except Exception as e:
            print(f"[ERROR] [{index}] Exception during captcha solving (Attempt {attempt}): {e}")
            log_error(index, f"Captcha solving error (Attempt {attempt}): {e}")
            if attempt < max_attempts:
                time.sleep(2)
                continue
            return False

def get_referral_link():
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                return f.read().strip()
        except Exception as e:
            print(f"[ERROR] Error reading config file: {e}")
            return None
    else:
        ref_link = os.getenv("REFERRAL_LINK")
        if ref_link:
            return ref_link
        print("[ERROR] No config.txt or REFERRAL_LINK environment variable found")
        return None

def get_thread_count():
    return 3  # Default thread count set to 3

def register_account(index, used_emails, ref_link, window_x, window_y, window_width, window_height, task_queue):
    options = Options()
    options.add_argument(f"--window-size={window_width},{window_height}")
    options.add_argument(f"--window-position={window_x},{window_y}")
    options.add_argument("--disable-gpu")
    options.add_argument("--no-sandbox")
    service = Service(ChromeDriverManager().install())
    driver = None

    max_attempts = 3
    for attempt in range(1, max_attempts + 1):
        try:
            driver = webdriver.Chrome(service=service, options=options)
            driver.get(ref_link)
            print(f"[WEB] [{index}] Opening link (Attempt {attempt})")
            if not wait_for_page_load(driver, 10):
                print(f"[ERROR] [{index}] Failed to load initial page (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return

            driver.set_window_size(window_width, window_height)
            driver.set_window_position(window_x, window_y)

            WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(text(), 'Register Now')]"))
            ).click()
            print(f"[CLICK] [{index}] Clicked register button (Attempt {attempt})")

            if not wait_for_page_load(driver, 10):
                print(f"[ERROR] [{index}] Failed to load registration page (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return

            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "ctl00_MainContentPlaceHolder_ctl00_Email"))
            )

            email = generate_unique_email(used_emails)
            password = "Pass" + ''.join(random.choices(string.ascii_letters + string.digits, k=8))

            driver.find_element(By.ID, "ctl00_MainContentPlaceHolder_ctl00_Email").send_keys(email)
            driver.find_element(By.ID, "ctl00_MainContentPlaceHolder_ctl00_Password").send_keys(password)
            driver.find_element(By.ID, "ctl00_MainContentPlaceHolder_ctl00_ConfirmPassword").send_keys(password)
            driver.find_element(By.ID, "TermsCheckBox").click()
            driver.find_element(By.ID, "PrivacyCheckBox").click()
            print(f"[INPUT] [{index}] Email: {email} | Password: {password} (Attempt {attempt})")

            solved = solve_captcha(index, driver)
            if not solved:
                print(f"[ERROR] [{index}] Captcha not solved (Attempt {attempt})")
                log_error(index, f"Captcha not solved (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return

            time.sleep(1)
            driver.find_element(By.ID, "ctl00_MainContentPlaceHolder_ctl00_CreateUserButton").click()

            try:
                WebDriverWait(driver, 3).until(
                    EC.presence_of_element_located((By.CSS_SELECTOR, ".error-message, .validation-summary-errors"))
                )
                error_message = driver.find_element(By.CSS_SELECTOR, ".error-message, .validation-summary-errors").text
                print(f"[ERROR] [{index}] Registration error: {error_message} (Attempt {attempt})")
                log_error(index, f"Registration error: {error_message} (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return
            except:
                pass

            if not wait_for_page_load(driver, 10):
                print(f"[ERROR] [{index}] Failed to load post-registration page (Attempt {attempt})")
                if attempt < max_attempts:
                    time.sleep(2)
                    continue
                return

            WebDriverWait(driver, 10).until(
                EC.url_contains("https://gamersunivers.com/user/default.aspx?afterlogin=1")
            )
            print(f"[SUCCESS] [{index}] Registration successful (Attempt {attempt})")

            with open(log_file, "a", encoding="utf-8") as f:
                f.write(f"{email},{password}\n")
            break
        except Exception as e:
            print(f"[ERROR] [{index}] Error (Attempt {attempt}): {e}")
            log_error(index, f"General error (Attempt {attempt}): {e}")
            if attempt < max_attempts:
                time.sleep(2)
                continue
            return
        finally:
            if driver:
                driver.quit()
            task_queue.task_done()

def worker(used_emails, ref_link, thread_count, window_width, window_height, task_queue):
    while not task_queue.empty():
        try:
            index = task_queue.get(timeout=1)
            window_x = ((index - 1) % thread_count) * window_width
            window_y = 0
            register_account(index, used_emails, ref_link, window_x, window_y, window_width, window_height, task_queue)
        except queue.Empty:  # Fixed: Use queue.Empty
            break
        except Exception as e:
            print(f"[ERROR] Worker error: {e}")
            log_error("Worker", str(e))

used_emails = load_used_emails()
ref_link = get_referral_link()
thread_count = get_thread_count()  # Will return 3 by default
total_accounts = 3000
task_queue = Queue()

try:
    options = Options()
    service = Service(ChromeDriverManager().install())
    temp_driver = webdriver.Chrome(service=service, options=options)
    screen_width, screen_height = temp_driver.execute_script("return [screen.width, screen.height];")
    temp_driver.quit()
except Exception as e:
    print(f"[WARN] Error getting screen size: {e}")
    screen_width, screen_height = 1920, 1080

base_width = 1200
base_height = 800
window_width = min(base_width, screen_width // thread_count - 10)
window_height = min(base_height, screen_height - 40)

max_concurrent_threads = min(thread_count, 3)

for i in range(1, total_accounts + 1):
    task_queue.put(i)

threads = []
for _ in range(max_concurrent_threads):
    t = threading.Thread(target=worker, args=(used_emails, ref_link, thread_count, window_width, window_height, task_queue))
    t.start()
    threads.append(t)

for t in threads:
    t.join()